
MODULES.moduleClasses["reyana_raindrops_socials"] = class {

    constructor(id) {
        this.namespace = "reyana_raindrops_socials";
        this.type = "overlay settings";
        this.id = id;
    }

    widgetDisplay = [
        {
            name: "Copy",
            icon: "copy",
            onclick(instance) {
                putInClipboard("https://widgets.casterlabs.co/org.reyana.raindrops/socials.html?id=" + instance.id);
            }
        }
    ]

    getDataToStore() {
        return this.settings;
    }

    onConnection(socket) {
        MODULES.emitIO(this, "config", this.settings, socket);

        const tokenData = CAFFEINATED.getResourceToken("org.reyana.raindrops");

        MODULES.emitIO(this, "nikki", {
            id: CAFFEINATED.uniqueStateId,
            url: tokenData.server_location,
            token: tokenData.token
        }, socket);
    }

    init() {
        koi.addEventListener("chat", (event) => {
            MODULES.emitIO(this, "event", event);
        });

        koi.addEventListener("donation", (event) => {
            if (this.settings.show_donations) {
                MODULES.emitIO(this, "event", event);
            }
        });
    }

    onSettingsUpdate() {
        MODULES.emitIO(this, "config", this.settings);
    }

    settingsDisplay = {
        theme: "select",
        max_per_line: "number",
        socials: "dynamic"
    };

    defaultSettings = {
        theme: [
            "Blue",
            "Green",
            "Orange",
            "Purple",
            "Red",
            "Yellow"
        ],
        max_per_line: 3,
        socials: {
            display: {
                type: "select",
                text: "input"
            },
            default: {
                type: [
                    "Discord",
                    "Twitter",
                    "Instagram",
                    "Facebook",
                    "Deviant Art",
                    "PayPal",
                    "Playstation",
                    "Reddit",
                    "Snapchat",
                    "Soundcloud",
                    "Steam",
                    "TikTok",
                    "tumblr",
                    "Venmo",
                    "VK",
                    "Xbox",
                    "YouTube"
                ],
                text: "",
            }
        }
    };

};