
MODULES.moduleClasses["reyana_raindrops_image_asset"] = class {

    constructor(id) {
        this.namespace = "reyana_raindrops_image_asset";
        this.type = "overlay settings";
        this.id = id;
    }

    widgetDisplay = [
        {
            name: "Copy",
            icon: "copy",
            onclick(instance) {
                putInClipboard("https://widgets.casterlabs.co/org.reyana.raindrops/image.html?namespace=" + instance.namespace + "&id=" + instance.id);
            }
        }
    ]

    getDataToStore() {
        return this.settings;
    }

    onConnection(socket) {
        MODULES.emitIO(this, "config", this.settings, socket);

        const tokenData = CAFFEINATED.getResourceToken("org.reyana.raindrops");

        MODULES.emitIO(this, "nikki", {
            id: CAFFEINATED.uniqueStateId,
            url: tokenData.server_location,
            token: tokenData.token
        }, socket);
    }

    onSettingsUpdate() {
        MODULES.emitIO(this, "config", this.settings);
    }

    settingsDisplay = {
        theme: "select"
    };

    defaultSettings = {
        theme: [
            "Blue",
            "Green",
            "Orange",
            "Purple",
            "Red",
            "Yellow"
        ]
    };

};