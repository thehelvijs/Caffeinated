
MODULES.moduleClasses["reyana_raindrops_chat"] = class {

    constructor(id) {
        this.namespace = "reyana_raindrops_chat";
        this.type = "overlay settings";
        this.id = id;
    }

    widgetDisplay = [
        {
            name: "Test",
            icon: "dice",
            onclick(instance) {
                koi.test("chat");
            }
        },
        {
            name: "Copy",
            icon: "copy",
            onclick(instance) {
                putInClipboard("https://widgets.casterlabs.co/org.reyana.raindrops/chat.html?id=" + instance.id);
            }
        }
    ]

    getDataToStore() {
        return this.settings;
    }

    onConnection(socket) {
        MODULES.emitIO(this, "config", this.settings, socket);

        const tokenData = CAFFEINATED.getResourceToken("org.reyana.raindrops");

        MODULES.emitIO(this, "nikki", {
            id: CAFFEINATED.uniqueStateId,
            url: tokenData.server_location,
            token: tokenData.token
        }, socket);
    }

    init() {
        koi.addEventListener("chat", (event) => {
            MODULES.emitIO(this, "event", event);
        });

        koi.addEventListener("donation", (event) => {
            if (this.settings.show_donations) {
                MODULES.emitIO(this, "event", event);
            }
        });
    }

    onSettingsUpdate() {
        MODULES.emitIO(this, "config", this.settings);
    }

    settingsDisplay = {
        show_donations: "checkbox",
        theme: "select"
    };

    defaultSettings = {
        show_donations: true,
        theme: [
            "Blue",
            "Green",
            "Orange",
            "Purple",
            "Red",
            "Yellow"
        ]
    };

};