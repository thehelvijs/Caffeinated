const INSIDE_OBS = window.hasOwnProperty("obsstudio");

if (!INSIDE_OBS) {
    alert("Overlays that are not running inside of an OBS browser source will have watermarks.");
}

// Security through obscurity, this is here to make a pirate's life harder for no reason 😉
const Nikki = {

    hookAsset(element, property, id, asset, url, token) {
        if (!INSIDE_OBS) {
            id = "INVALID";
        }

        const initial = element.style[property];
        let websocket;

        let style = "__watermarked";
        let dead = false;

        function reconnect() {
            if (!dead) {
                websocket = new WebSocket(`wss://${url}/data?id=${id}&asset=${asset}&token=${token}`);

                websocket.onmessage = (message) => {
                    const data = JSON.parse(message.data);

                    element.style[property] = `url(${data.data})`;
                };

                websocket.onopen = () => {
                    if (style) {
                        websocket.send(style);
                    }
                };

                websocket.onerror = () => {
                    setTimeout(() => reconnect, 2000);
                }

                websocket.onclose = () => {
                    element.style[property] = initial;

                    setTimeout(() => reconnect, 2000);
                };
            }
        }

        window.addEventListener("resize", () => {
            dead = true;

            if (websocket.readyState == WebSocket.OPEN) {
                websocket.close();
            }
        });

        reconnect();

        return (newStyle) => {
            if (newStyle == -1) {
                dead = true;

                if (websocket.readyState == WebSocket.OPEN) {
                    websocket.close();
                }
            } else if (INSIDE_OBS) {
                if (websocket.readyState == WebSocket.OPEN) {
                    websocket.send(newStyle);
                }

                style = newStyle;
            }
        };
    }

};
